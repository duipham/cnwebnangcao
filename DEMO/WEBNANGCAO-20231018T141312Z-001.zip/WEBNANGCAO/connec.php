<?php 
$servername="localhost";
$username="root";
$password="";
$database="66PM56";
$conn = new mysqli($servername,$username,$password,$database);
echo $conn->connect_error;
?>